﻿using System;

namespace GetTheCentury
{
    internal class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
