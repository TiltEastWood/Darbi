---?image=template/img/pencils.jpg
@title[Announcement Templates]

## @color[black](Announcement<br>Slide Templates)

@fa[arrow-down text-black]

@snap[south docslink span-50]
[The Template Docs](https://gitpitch.com/docs/the-template)
@snapend


+++
@title[Big News Teaser]

@snap[north announce-big-news]
BIG
@snapend

@snap[south announce-big-news text-orange]
NEWS
@snapend

@snap[south-west template-note text-gray]
Big-news teaser template.
@snapend


+++
@title[New Release Teaser]

## New Release

@css[text-pink](@fa[calendar] January, 2019.)

@snap[south-west template-note text-gray]
Upcoming-release teaser template.
@snapend


+++?color=linear-gradient(to top, #ffb347, #ffcc33)
@title[Coming Soon Teaser]

@snap[midpoint announce-coming-soon text-white]
COMING
@snapend

@snap[south text-white]
SOON ;)
@snapend

@snap[south-west template-note text-white]
Coming-soon teaser template.
@snapend
