int x = 1;
Console.WriteLine(x);
// output 1
x = x + 1;
Console.WriteLine(x);
// output 2
x += 2;
Console.WriteLine(x);
// output 4
x++; // same as x += 1
     // and x = x + 1
Console.WriteLine(x);
// output 5