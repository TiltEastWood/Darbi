﻿using System;
using System.Collections.Generic;

namespace VideoStore
{
    class VideoStore
    {

        public VideoStore()
        {
            
        }

        public void AddVideo(string title)
        {
            
        }
        
        public void Checkout(string title)
        {

        }

        public void ReturnVideo(string title)
        {
        }

        public void TakeUsersRating(double rating, string title)
        {
            
        }

        public void ListInventory()
        {
            
        }
    }
}
