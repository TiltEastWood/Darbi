    class Car
    {
        string brand;
        public Car(string brand)
        {
            this.brand = brand;
        }
    }

    Car car = new Car("Audi");