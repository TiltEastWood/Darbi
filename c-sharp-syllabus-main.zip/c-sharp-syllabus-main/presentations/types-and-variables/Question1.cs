static void Main(string[] args)
{
    int t;
    Console.WriteLine(t);
    // What will be the output?
    // 1. 0
    // 2. runtime error
    // 3. compilation error
    // 4. null
}