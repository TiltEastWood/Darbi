namespace MakeSounds
{
    interface ISound
    {
        void PlaySound();
    } 
    
}