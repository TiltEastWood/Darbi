using System;

namespace WhileQuiz
{
    class Program
    {
        private static void Main(string[] args)
        {
            var count = 0;
            while (count < 100) {
                // Point A
                Console.WriteLine("Welcome to Java!");
                count++;
                // Point B
            }
            // Point C
            
            
            //Which statement is true?
            // 1. count < 100 is always true at Point B 
            // 2. count < 100 is always false at Point B
            // 3. count < 100 is always true at Point A
            //    and count < 100 is always false at Point C
            // 4. count < 100 is always true at Point C
        }
    }
}