class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine(0.5 - 0.1 - 0.1 - 0.1 - 0.1 - 0.1);
        //what will be the output?
    }
}