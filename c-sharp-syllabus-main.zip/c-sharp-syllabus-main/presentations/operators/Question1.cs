double x = 1 / 2;
Console.WriteLine(x);
// output?